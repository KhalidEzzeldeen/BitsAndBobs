These flag images come from the CIA World Factbook, available at:

http://www.odci.gov/cia/publications/factbook/

Mime types for GIF and JPEG files are:

*.gif files: image/gif
*.jpg files: image/jpeg
