The transaction.* scripts show how to implement transactions in various
languages.

get_ticket.* show transactional and nontransactional solutions to a
problem that can be solved both ways.  booksales*.py likewise.
