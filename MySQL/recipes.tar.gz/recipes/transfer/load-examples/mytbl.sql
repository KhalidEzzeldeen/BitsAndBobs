# mytbl.sql

# Create test table for LOAD DATA example

DROP TABLE IF EXISTS mytbl;
CREATE TABLE mytbl
(
  c1  CHAR(20),
  c2  CHAR(20)
)
;
